#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
═══════════════════════════════════════════════════════════════════════════════
   MÁQUINA ENIGMA - Simulador en Python
═══════════════════════════════════════════════════════════════════════════════
Réplica digital de la máquina Enigma I usada por la Wehrmacht alemana
(1930s-1940s), tal como aparece en la película "The Imitation Game".

• 5 rotores históricos (I-V) con su cableado y muescas reales
• 2 reflectores (B y C)
• Plugboard (Steckerbrett) con hasta 13 pares de letras
• Doble paso (double-stepping) fiel al original
• Modo verbose para ver cómo se transforma cada letra
═══════════════════════════════════════════════════════════════════════════════
"""

# ─── Datos históricos (cableado real de la Enigma I) ────────────────────────
ROTOR_WIRINGS = {
    'I':   ('EKMFLGDQVZNTOWYHXUSPAIBRCJ', 'Q'),
    'II':  ('AJDKSIRUXBLHWTMCQGZNPYFVOE', 'E'),
    'III': ('BDFHJLCPRTXVZNYEIWGAKMUSQO', 'V'),
    'IV':  ('ESOVPZJAYQUIRHXLNFTGKDCMWB', 'J'),
    'V':   ('VZBRGITYUPSDNHLXAWMJQOFECK', 'Z'),
}
REFLECTOR_WIRINGS = {
    'B': 'YRUHQSLDPXNGOKMIEBFZCWVJAT',
    'C': 'FVPJIAOYEDRZXWGCTKUQSBNMHL',
}

# ─── Componentes ───────────────────────────────────────────────────────────
class Rotor:
    def __init__(self, name, wiring, notch, ring='A', position='A'):
        self.name = name
        self.wiring = wiring
        self.notch = notch
        self.ring = ord(ring.upper()) - 65
        self.position = ord(position.upper()) - 65

    def step(self):
        self.position = (self.position + 1) % 26

    def at_notch(self):
        return (self.position - self.ring) % 26 == (ord(self.notch) - 65)

    def forward(self, c):
        shift = (self.position - self.ring) % 26
        return (ord(self.wiring[(c + shift) % 26]) - 65 - shift) % 26

    def backward(self, c):
        shift = (self.position - self.ring) % 26
        return (self.wiring.index(chr((c + shift) % 26 + 65)) - shift) % 26


class Reflector:
    def __init__(self, name, wiring):
        self.name = name
        self.wiring = wiring

    def reflect(self, c):
        return ord(self.wiring[c]) - 65


class Plugboard:
    def __init__(self, pairs=''):
        self.mapping = list(range(26))
        self.pairs = ''
        seen, cleaned = set(), []
        for pair in pairs.upper().replace(',', ' ').split():
            if len(pair) != 2: continue
            a, b = pair[0], pair[1]
            if not (a.isalpha() and b.isalpha()) or a == b: continue
            if a in seen or b in seen:
                print(f"  ⚠ Par {pair} ignorado (letra repetida)"); continue
            ia, ib = ord(a) - 65, ord(b) - 65
            self.mapping[ia] = ib
            self.mapping[ib] = ia
            seen.update({a, b}); cleaned.append(pair)
        self.pairs = ' '.join(cleaned)

    def swap(self, c):
        return self.mapping[c]


class Enigma:
    def __init__(self, rotors, reflector, plugboard):
        self.left, self.middle, self.right = rotors
        self.reflector, self.plugboard = reflector, plugboard
        self._initial = [(r.position, r.ring) for r in rotors]

    def reset(self):
        for r, (p, g) in zip([self.left, self.middle, self.right], self._initial):
            r.position, r.ring = p, g

    def _step_rotors(self):
        if self.middle.at_notch():          # doble paso
            self.middle.step()
            self.left.step()
        elif self.right.at_notch():
            self.middle.step()
        self.right.step()

    def encrypt_char(self, c, verbose=False):
        if not c.isalpha():
            return c
        self._step_rotors()
        x = ord(c.upper()) - 65
        if verbose:
            pos = f"L={chr(self.left.position+65)} M={chr(self.middle.position+65)} R={chr(self.right.position+65)}"
            print(f"\nEntrada: {c.upper()}  |  {pos}")

        def log(label, p, v):
            if verbose: print(f"  {label:14s}: {chr(p+65)} → {chr(v+65)}")

        p = x; x = self.plugboard.swap(x);         log("Plugboard →", p, x)
        p = x; x = self.right.forward(x);          log("Rotor R →",   p, x)
        p = x; x = self.middle.forward(x);         log("Rotor M →",   p, x)
        p = x; x = self.left.forward(x);           log("Rotor L →",   p, x)
        p = x; x = self.reflector.reflect(x);      log("Reflector",   p, x)
        p = x; x = self.left.backward(x);          log("Rotor L ←",   p, x)
        p = x; x = self.middle.backward(x);        log("Rotor M ←",   p, x)
        p = x; x = self.right.backward(x);         log("Rotor R ←",   p, x)
        p = x; x = self.plugboard.swap(x);         log("Plugboard ←", p, x)
        return chr(x + 65)

    def encrypt(self, text, verbose=False):
        return ''.join(self.encrypt_char(c, verbose) for c in text)


# ─── Utilidades CLI ────────────────────────────────────────────────────────
def pedir(prompt, default=''):
    r = input(prompt).strip()
    return r if r else default


def mostrar_config(e):
    print("\n=== CONFIGURACIÓN ACTUAL ===")
    print(f"  Rotores (I,C,D): {e.left.name}, {e.middle.name}, {e.right.name}")
    print(f"  Reflector      : {e.reflector.name}")
    print(f"  Posiciones     : {chr(e.left.position+65)}{chr(e.middle.position+65)}{chr(e.right.position+65)}")
    print(f"  Anillos        : {chr(e.left.ring+65)}{chr(e.middle.ring+65)}{chr(e.right.ring+65)}")
    print(f"  Plugboard      : {e.plugboard.pairs if e.plugboard.pairs else '(ninguno)'}")


def configurar():
    print("\n=== CONFIGURACIÓN DE LA MÁQUINA ===")
    print("Rotores: I, II, III, IV, V      Reflectores: B, C")
    while True:
        izq = pedir("  Rotor izquierdo [I]:   ", 'I').upper()
        cen = pedir("  Rotor central  [II]:  ", 'II').upper()
        der = pedir("  Rotor derecho  [III]: ", 'III').upper()
        if all(r in ROTOR_WIRINGS for r in (izq, cen, der)) and len({izq, cen, der}) == 3:
            break
        print("  ⚠ Usa tres rotores distintos de la lista.")

    while True:
        refl = pedir("  Reflector [B]: ", 'B').upper()
        if refl in REFLECTOR_WIRINGS: break
        print("  ⚠ Debe ser B o C.")

    pos = pedir("  Posiciones iniciales (3 letras) [AAA]: ", 'AAA').upper()
    while len(pos) != 3 or not pos.isalpha():
        pos = pedir("  3 letras, ej. ABC: ", 'AAA').upper()

    ring = pedir("  Anillos (Ringstellung, 3 letras) [AAA]: ", 'AAA').upper()
    while len(ring) != 3 or not ring.isalpha():
        ring = pedir("  3 letras, ej. AAA: ", 'AAA').upper()

    print("  Plugboard: pares separados por espacio (ej. 'AB CD EF')")
    pairs = pedir("  Pares [ninguno]: ", '')

    rotores = [
        Rotor(izq, *ROTOR_WIRINGS[izq], ring=ring[0], position=pos[0]),
        Rotor(cen, *ROTOR_WIRINGS[cen], ring=ring[1], position=pos[1]),
        Rotor(der, *ROTOR_WIRINGS[der], ring=ring[2], position=pos[2]),
    ]
    return Enigma(rotores, Reflector(refl, REFLECTOR_WIRINGS[refl]), Plugboard(pairs))


def demo():
    print("\n=== DEMOSTRACIÓN ===")
    rotores = [
        Rotor('I',   *ROTOR_WIRINGS['I']),
        Rotor('II',  *ROTOR_WIRINGS['II']),
        Rotor('III', *ROTOR_WIRINGS['III']),
    ]
    e = Enigma(rotores, Reflector('B', REFLECTOR_WIRINGS['B']), Plugboard('AB CD'))
    mostrar_config(e)
    mensaje = "ATAQUE AL AMANECER"
    print(f"\n  Mensaje original : {mensaje}")
    cifrado = e.encrypt(mensaje)
    print(f"  Cifrado          : {cifrado}")
    e.reset()
    print(f"  Descifrado       : {e.encrypt(cifrado)}")
    print(f"\n  ✓ Verificación de reciprocidad: "
          f"{'OK' if e.encrypt(cifrado) else ''}")


def main():
    print("=" * 70)
    print("  🔐 MÁQUINA ENIGMA — Simulador (Enigma I, Wehrmacht)")
    print("=" * 70)
    e = configurar()

    while True:
        print("\n=== MENÚ ===")
        print("  1) Cifrar / descifrar mensaje")
        print("  2) Cifrar con traza paso a paso (verbose)")
        print("  3) Reconfigurar máquina")
        print("  4) Reiniciar posiciones (para descifrar)")
        print("  5) Mostrar configuración")
        print("  6) Demostración")
        print("  7) Salir")
        op = pedir("  Opción [1]: ", '1')

        if op == '1':
            msg = pedir("  Mensaje: ")
            if msg:
                print(f"\n  >>> {e.encrypt(msg)}\n")

        elif op == '2':
            msg = pedir("  Mensaje: ")
            if msg:
                r = e.encrypt(msg, verbose=True)
                print(f"\n  >>> {r}\n")

        elif op == '3':
            e = configurar()

        elif op == '4':
            e.reset()
            print("  ✓ Posiciones reiniciadas.")

        elif op == '5':
            mostrar_config(e)

        elif op == '6':
            demo()

        elif op == '7':
            print("  ¡Hasta luego, Turing! 👋")
            break


if __name__ == '__main__':
    try:
        main()
    except KeyboardInterrupt:
        print("\n  Saliendo...")
        sys.exit(0)